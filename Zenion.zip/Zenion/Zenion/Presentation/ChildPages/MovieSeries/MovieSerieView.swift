//
//  MovieSerieView.swift
//  Zenion
//
//  Created by macbook on 23.04.23.
//

import SwiftUI

//struct MovieSerieView: View {
//    var movies : MovieVideo
//    var body: some View {
//        ZStack{
//            Color("Dark")
//                .ignoresSafeArea()
//            MovieSerieList(headerText: "Series", movies: movies, width: 200, height: 400)
//        }
//    }
//}
//
//struct MovieSerieView_Previews: PreviewProvider {
//    static var previews: some View {
//        MovieSerieView(movies: MovieVideo(name: "fdsfdf", photo: "test", video: []))
//    }
//}
