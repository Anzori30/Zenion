//
//  CreatAccount.swift
//  Zenion
//
//  Created by macbook on 05.04.23.
//

import SwiftUI

struct CreatAccount: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CreatAccount_Previews: PreviewProvider {
    static var previews: some View {
        CreatAccount()
    }
}
