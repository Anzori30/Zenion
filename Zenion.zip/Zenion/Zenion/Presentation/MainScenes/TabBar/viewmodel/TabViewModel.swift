//
//  TabViewModel.swift
//  Zenion
//
//  Created by macbook on 18.04.23.
//

import SwiftUI

class TabViewModel: ObservableObject {
}
