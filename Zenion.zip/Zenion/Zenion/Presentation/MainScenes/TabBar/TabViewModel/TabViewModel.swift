//
//  TabViewModel.swift
//  Zenion
//
//  Created by macbook on 23.04.23.
//

import SwiftUI

struct TabViewModel: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct TabViewModel_Previews: PreviewProvider {
    static var previews: some View {
        TabViewModel()
    }
}
